
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's21413ce668a25466': `Tambah Buku`,
's3d93f9ea0c5a13fa': `Gambar`,
's5d929ff1619ac0c9': `Cari`,
's63d894b1ddb06289': `Deskripsi`,
's6abb1cd87fe0114e': `Halaman utama`,
's8a4ebf3de3168041': `Dibuat oleh seseorang`,
's9ae6b028d9f5cbeb': `Pencarian`,
'sac8252732f2edb19': `Tanggal`,
'sb3d4f79d9d8b71e5': `Kirim`,
'scb086ff39521eb71': `Tambahkan Buku`,
'sef1ae18cfaa23e14': `required`,
'sef49aec68fd1dc66': `Nama`,
'sfe46f400c6b86658': `Lihat`,
    };
  